USE PV_521_DDL

--SQLQuery3 - CREATE Shedule.sql

--CREATE TABLE Shedule
--(
--	lesson_id		INT						PRIMARY KEY,
--	date			DATE					NOT NULL,
--	time			TIME					NOT NULL,
--	[group]			INT
--	CONSTRAINT		FK_Shedule_Group		FOREIGN KEY		REFERENCES	Groups(group_id),
--	discipline		SMALLINT				NOT NULL
--	CONSTRAINT		FK_Shedule_Disciplines	FOREIGN KEY		REFERENCES	Disciplines(discipline_id),
--	teacher			INT						NOT NULL
--	CONSTRAINT		FK_Shedule_Teachers		FOREIGN KEY		REFERENCES	Teachers(teacher_id),
--	[subject]		SMALLINT				NOT	NULL,
--	status			BIT						NOT NULL,
--);

--CREATE TABLE HomeWorks
--(
--	[group]			INT,
--	lesson			INT,
--	CONSTRAINT		FK_Homeworks_Groups		FOREIGN KEY([group])		REFERENCES	Groups(group_id),
--	CONSTRAINT		FK_Homeworks_Shedule	FOREIGN KEY(lesson)			REFERENCES	Shedule(lesson_id),
--	task			BINARY(1000)				NULL,
--	deadlie			INT							NULL
--);

--CREATE TABLE ResultsHW
--(
--	student			INT
--	CONSTRAINT		FK_ResultsHW_Students	FOREIGN KEY				REFERENCES	Students(student_id),
--	[group]			INT
--	CONSTRAINT		FK_ResultsHW_Groups		FOREIGN KEY				REFERENCES	Groups(group_id),
--	lesson			INT,
--	CONSTRAINT		FK_ResultsHW_Shedule	FOREIGN KEY(lesson)		REFERENCES	Shedule(lesson_id),
--	result			BINARY(1000)			NULL,
--	report			INT						NULL,
--	grade			INT						NULL
--);
--CREATE TABLE Grades
--(
--	student INT,
--	lesson	INT,
--	CONSTRAINT		FK_Grades_Students		FOREIGN KEY(student)		REFERENCES	Students(student_id),
--	CONSTRAINT		FK_Grades_Shedule		FOREIGN KEY(lesson)			REFERENCES	Shedule(lesson_id)
--);

--DROP TABLE ResultsHW