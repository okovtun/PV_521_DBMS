--SQLQuery - CREATE PV_521_ALL_IN_ONE.sql

CREATE DATABASE PV_521_ALL_IN_ONE
ON
(
	NAME		=	PV_521_ALL_IN_ONE,
	FILENAME	=	'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\PV_521_ALL_IN_ONE.mdf',
	SIZE		=	8 MB,
	MAXSIZE		=	500 MB,
	FILEGROWTH	=	8 MB
)
LOG ON
(
	NAME		=	PV_521_ALL_IN_ONE_log,
	FILENAME	=	'C:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\PV_521_ALL_IN_ONE.ldf',
	SIZE		=	8 MB,
	MAXSIZE		=	500 MB,
	FILEGROWTH	=	8 MB
)
USE PV_521_ALL_IN_ONE;

CREATE TABLE Directions
(
	direction_id		TINYINT			PRIMARY KEY,
	direction_name		NVARCHAR(150)	NOT NULL,
);

CREATE TABLE Groups
(
	group_id		INT			PRIMARY KEY,
	group_name		NVARCHAR(24)	NOT NULL,
	direction		TINYINT			NOT NULL		--описание поля
	CONSTRAINT		FK_Groups_Direction	FOREIGN KEY REFERENCES	Directions(direction_id)
--	CONSTRAINT		FK_Имя_ВнешнегоКлюча	FOREIGN KEY REFERENCES	Таблица(первичный_ключ_внешней_таблицы)
);

CREATE TABLE Students
(
	student_id		INT				PRIMARY KEY IDENTITY(1,1), --IDENTITY - Autoincrement
	last_name		NVARCHAR(50)	NOT NULL,
	first_name		NVARCHAR(50)	NOT NULL,
	middle_name		NVARCHAR(50)	NULL,
	birth_dat		DATE			NOT NULL,
	--group - это ключевое слово языка Transact-SQL. Ключевые слова можно использовать для именования полей,
	-- но в таком случае их нужно брать в квадратные скобки.
	[group]			INT				NOT NULL
	CONSTRAINT		FK_Students_Group	FOREIGN KEY REFERENCES Groups(group_id)
);

CREATE TABLE Teachers
(
	teacher_id		INT				PRIMARY KEY,
	last_name		NVARCHAR(50)	NOT NULL,
	first_name		NVARCHAR(50)	NOT NULL,
	middle_name		NVARCHAR(50)	NULL,
	birth_date		DATE			NOT NULL
);

CREATE TABLE Disciplines
(
	discipline_id		SMALLINT		PRIMARY KEY,
	discipline_name		NVARCHAR(256)	NOT NULL,
	number_of_lessons	TINYINT			NOT NULL,
);

CREATE TABLE DisciplinesDirectionsRelation
(
	discipline			SMALLINT,
	direction			TINYINT,
	PRIMARY KEY(discipline, direction),
	CONSTRAINT FK_DDR_Discipline	FOREIGN KEY (discipline)	REFERENCES Disciplines(discipline_id),
	CONSTRAINT FK_DDR_Direction		FOREIGN KEY (direction)		REFERENCES Directions(direction_id)
);

CREATE TABLE TeachersDisciplinesRelation
(
	teacher			INT,
	discipline		SMALLINT,
	PRIMARY KEY(teacher, discipline),
	CONSTRAINT		FK_TDR_Teacher		FOREIGN KEY	(teacher)		REFERENCES	Teachers(teacher_id),
	CONSTRAINT		FK_TDR_Discipline	FOREIGN KEY	(discipline)	REFERENCES	Disciplines(discipline_id)
);

CREATE TABLE RequiredDisciplines
(
	discipline				SMALLINT,
	required_discipline		SMALLINT,
	PRIMARY KEY(discipline, required_discipline),
	CONSTRAINT	FK_RDiscplines_Discipline	FOREIGN KEY (discipline)				REFERENCES	Disciplines(discipline_id),
	CONSTRAINT	FK_RDisciplines_Required	FOREIGN KEY (required_discipline)		REFERENCES	Disciplines(discipline_id)
);

CREATE TABLE DependentDiscplines
(
	discipline				SMALLINT,
	dependent_discipline	SMALLINT,
	PRIMARY KEY(discipline, dependent_discipline),
	CONSTRAINT	FK_DD_Discipline	FOREIGN KEY (discipline)				REFERENCES	Disciplines(discipline_id),
	CONSTRAINT	FK_DD_Dependent		FOREIGN KEY (dependent_discipline)		REFERENCES Disciplines(discipline_id)
);

CREATE TABLE Exams
(
	student			INT,
	discipline		SMALLINT,
	PRIMARY KEY(student, discipline),
	CONSTRAINT		FK_SDR_Student		FOREIGN KEY	(student)		REFERENCES	Students(student_id),
	CONSTRAINT		FK_SDR_Discipline	FOREIGN KEY	(discipline)	REFERENCES	Disciplines(discipline_id)
);

CREATE TABLE Schedule
(
	lesson_id		INT				PRIMARY KEY,
	[date]			DATE			NOT NULL,
	[time]			TIME(7)			NOT NULL,
	[subject]		VARCHAR(256)	NOT NULL,
	[status]		BIT				NOT NULL,
	[group]			INT
	CONSTRAINT		FK_GScR_Group		FOREIGN KEY	REFERENCES Groups(group_id),
	discipline		SMALLINT
	CONSTRAINT		FK_DScR_Discipline		FOREIGN KEY REFERENCES Disciplines(discipline_id),
	teacher			INT	
	CONSTRAINT		FK_TScR_Teacher		FOREIGN KEY REFERENCES Teachers(teacher_id)
);


CREATE TABLE HomeWorks
(
	lesson		INT		PRIMARY KEY,
	[group]		INT
	CONSTRAINT	FK_HWGR_Group		FOREIGN KEY	REFERENCES	Groups(group_id),
	task		BINARY(1000)	NOT NULL,
	deadline	INT				NOT NULL,

);

CREATE TABLE Grades
(
	student		INT,
	lesson		INT,
	PRIMARY KEY(student, lesson),
	CONSTRAINT	FK_ScStR_Student		FOREIGN KEY (student)	REFERENCES	Students(student_id),
	CONSTRAINT	FK_ScStR_Schedule		FOREIGN KEY	(lesson)	REFERENCES	Schedule(lesson_id)
);

CREATE TABLE ResultsHW
(
	student		INT,
	[group]		INT,
	lesson		INT,
	result		BINARY(1000)	NOT NULL,
	report		INT				NOT NULL,
	grade		INT				NOT NULL,
	PRIMARY KEY(student, [group], lesson),
	CONSTRAINT		FK_StRHWR_Student		FOREIGN KEY (student)	REFERENCES Students(student_id),
	CONSTRAINT		FK_GRHWR_Group		FOREIGN KEY ([group])		REFERENCES Groups(group_id),
	CONSTRAINT		FK_RHWHWR_HW		FOREIGN KEY (lesson)		REFERENCES HomeWorks(lesson)

);